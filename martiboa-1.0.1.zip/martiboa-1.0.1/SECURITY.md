# Security Policy
TO BE ADDED

## Supported Versions



| Version | Supported          |
| ------- | ------------------ | 
| 1.0.1   | :white_check_mark: |
| < 1.0.0 | :x:                |

## Reporting a Vulnerability

TO BE ADDED
